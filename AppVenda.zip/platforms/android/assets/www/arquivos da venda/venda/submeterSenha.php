<?
	$senha = $_POST['senha'];
	
	if($senha == "fktefkte")
		echo $isSenha = '1';
	
?>